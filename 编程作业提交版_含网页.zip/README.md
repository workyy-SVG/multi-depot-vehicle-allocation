# 多周期需求下的多仓库车辆分配优化

最终评分结果在 output/，与 input_data/ 的九份输入逐一同名对应。
每行依次是该仓库分配的车辆数，以及从 0 开始的车辆编号。

optimize.py 包含车辆分配搜索算法。先安装 requirements.txt 中的依赖，
然后运行下面的命令进行新的启发式搜索：

    python -m pip install -r requirements.txt
    python optimize.py input_data --outdir fresh_search --reference output

PyVRP 按时间限额求解路线，新搜索的结果可能随机器和运行时负载改变。
为了复现此次提交的九份固定结果，可运行：

    python generate.py input_data --outdir regenerated

generate.py 核对输入内容，读取已发布的分配结果，并验证每辆车恰好分配一次。
这条命令复现提交文件，不执行新的搜索。

网页展示在 docs/index.html，可直接在浏览器打开。
网页引用外部 Plotly 脚本，查看交互图需要联网。
