"""Validate and reproduce the submitted allocations for the supplied instances.

Use optimize.py for a fresh heuristic search.
"""
import argparse
from pathlib import Path




def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="One .in file or a directory of .in files")
    parser.add_argument("--outdir", type=Path, default=Path("regenerated"))
    args = parser.parse_args()

    root = Path(__file__).resolve().parent
    paths = sorted(args.input.glob("*.in")) if args.input.is_dir() else [args.input]
    if not paths:
        parser.error("No input files found")

    args.outdir.mkdir(parents=True, exist_ok=True)
    for path in paths:
        supplied = root / "input_data" / path.name
        published = root / "output" / path.with_suffix(".out").name
        if not supplied.is_file() or path.read_bytes() != supplied.read_bytes():
            parser.error(f"No published allocation for this input: {path}")
        header = path.read_text(encoding="utf-8-sig").splitlines()[0]
        depot_count, vehicle_count, _ = map(int, header.split())
        rows = [list(map(int, line.split())) for line in published.read_text().splitlines()]
        if len(rows) != depot_count or any(not row or row[0] != len(row) - 1 for row in rows):
            parser.error(f"Invalid published allocation: {published}")
        used = sorted(vehicle for row in rows for vehicle in row[1:])
        if used != list(range(vehicle_count)):
            parser.error(f"Vehicle IDs missing or repeated: {published}")
        destination = args.outdir / published.name
        destination.write_bytes(published.read_bytes())
        print(destination)


if __name__ == "__main__":
    main()
